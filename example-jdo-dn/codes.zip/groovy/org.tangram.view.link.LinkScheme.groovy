package org.tangram.rdbms.example;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.tangram.Constants;
import org.tangram.content.Content;
import org.tangram.content.BeanFactory;
import org.tangram.controller.DefaultController;
import org.tangram.view.Utils;
import org.tangram.view.TargetDescriptor;
import org.tangram.view.link.Link;
import org.tangram.view.link.LinkScheme;

import org.tangram.rdbms.solution.RootTopic;
import org.tangram.rdbms.solution.Linkable;
import org.tangram.rdbms.solution.Topic;
import org.tangram.rdbms.solution.ImageData;

public class ExampleLinkScheme implements LinkScheme {
  
  private static Log log = LogFactory.getLog(ExampleLinkScheme.class);

  private BeanFactory beanFactory;
  
  
  public void setBeanFactory(BeanFactory factory) {
    beanFactory = factory;
  } // setBeanFactory()
  
  
  public void setDefaultController(DefaultController defaultController) {
    // Automagically set default view
    defaultController.getCustomLinkViews().add(Constants.DEFAULT_VIEW);
  } // setDefaultController()


  public Link createLink(HttpServletRequest request, HttpServletResponse response, Object bean, String action, String view) {    
        Link result = null;
        if ((action==null)&&(view==null)) {
            if (bean instanceof RootTopic) {
                result = new Link();
                result.setUrl("/");
            } else {
                if ((bean instanceof Topic)||(bean instanceof ImageData)) {
                    String title = "-";
                    if (bean instanceof Linkable) {
                        try {
                            title = Utils.urlize(((Linkable)bean).getTitle());
                        } catch (UnsupportedEncodingException uee) {
                            log.error("createLink()", uee);
                        } // try
                    } // if
                    String url = "/"+title+"/"+((Content)bean).getId();
                    result = new Link();
                    result.setUrl(url);
                } // if
            } // if
        } // if
        return result;
  } // createLink()

    
  private TargetDescriptor rootDescriptor = null;;
  
  
  public TargetDescriptor parseLink(String url, HttpServletResponse response) {
    TargetDescriptor result = null;
    if (url.equals("/")) {
        try {
            if (rootDescriptor==null) {
                List<RootTopic> rs = beanFactory.listBeans(RootTopic.class, null);
                RootTopic root = null;
                if (rs.size()==1) {
                    root = rs.get(0);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Have "+rs.size()+" RootTopics in data store");
                } // if
                rootDescriptor = new TargetDescriptor(root, null, null);
            } // if
            result = rootDescriptor;
        } catch (Exception e) {
            result = new TargetDescriptor(e, null, null);
        } // try/catch
      } else {
          String id = null;
          Object bean  = null;
          String[] elements = url.split("/");
          for (String element : elements) {
            if (element.indexOf(":") > 0) {
              id = element;
              bean = beanFactory.getBean(element);
            } // if
          } // for
          if (bean != null) {
              result = new TargetDescriptor(bean, null, null);
          } else {
              throw new RuntimeException("no content with id "+id+" in repository.");
          } // if
      } // if
      return result;
  } // parseLink()
    
} // ExampleLinkScheme
